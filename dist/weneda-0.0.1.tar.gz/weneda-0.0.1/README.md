# weneda
Python module for editing and styling a text.

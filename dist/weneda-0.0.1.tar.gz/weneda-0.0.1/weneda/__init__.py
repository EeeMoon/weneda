"""
Module for editing text.
"""

from .style import *
from .format import *